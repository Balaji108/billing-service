package com.billing.domain;

public enum Category {
	DRINK, FOOD
}
